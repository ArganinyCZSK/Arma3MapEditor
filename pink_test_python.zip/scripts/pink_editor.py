#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals

import io
import json
import os
import shutil
import sys

PLUGIN_ID = "pink_theme"
LEGACY_IDS = ["ruzovy_vzhled"]

DARK = {
    "Bg": "#3E1B30", "Panel": "#4A2139", "Surface": "#5C2A47", "SurfaceHover": "#713457",
    "Input": "#331526", "Border": "#8E4670", "Text": "#FFE6F2", "Muted": "#E3A6C6",
    "Accent": "#FF5FAF", "AccentDark": "#A32E6B", "StripBg": "#38182B", "LogBg": "#2B1020",
}
LIGHT = {
    "Bg": "#FFD1E6", "Panel": "#FFDDEC", "Surface": "#FFE9F3", "SurfaceHover": "#FFC2DD",
    "Input": "#FFF5FA", "Border": "#E890B8", "Text": "#3D1028", "Muted": "#8A4A6B",
    "Accent": "#E0218A", "AccentDark": "#F7A8CC", "StripBg": "#FFC8E0", "LogBg": "#FFF0F7",
}

PY2 = sys.version_info[0] == 2


def u(text):
    if isinstance(text, bytes):
        return text.decode("utf-8")
    return text


def out(text):
    line = u(text) + u("\n")
    if PY2:
        sys.stdout.write(line.encode("utf-8"))
    else:
        sys.stdout.buffer.write(line.encode("utf-8"))
    sys.stdout.flush()


def env(name):
    value = os.environ.get(name)
    if value is not None and PY2 and isinstance(value, bytes):
        value = value.decode(sys.getfilesystemencoding() or "mbcs")
    return value


def read_json(path):
    with io.open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path, data):
    text = u(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
    with io.open(path, "w", encoding="utf-8") as f:
        f.write(text)


def editor_info():
    path = env("ARG_MAPEDITOR_CONTEXT")
    if not path or not os.path.isfile(path):
        return {}
    try:
        return read_json(path)
    except (IOError, OSError, ValueError):
        return {}


def load_state(path):
    try:
        data = read_json(path)
    except (IOError, OSError, ValueError):
        data = {}
    enabled = data.get("Enabled") or data.get("enabled") or []
    order = data.get("Order") or data.get("order") or []
    return list(enabled), list(order)


def save_state(path, enabled, order):
    write_json(path, {"Enabled": enabled, "Order": order})


def remove_plugin(plugins_dir, plugin_id, enabled, order):
    folder = os.path.join(plugins_dir, plugin_id)
    if os.path.isdir(folder):
        shutil.rmtree(folder)
    return [x for x in enabled if x != plugin_id], [x for x in order if x != plugin_id]


def main():
    appdata = env("APPDATA")
    if not appdata:
        out("The APPDATA variable is missing - this code is meant for Windows.")
        return 1
    base = os.path.join(appdata, "ArgMapEditor")
    plugins_dir = os.path.join(base, "plugins")
    folder = os.path.join(plugins_dir, PLUGIN_ID)
    state_path = os.path.join(base, "plugins.json")
    enabled, order = load_state(state_path)

    out("Python {0}.{1}.{2}".format(*sys.version_info[:3]))
    info = editor_info()
    if info:
        out(u("Map in the editor: {0} ({1} x {1}, {2} m/cell), active tool: {3}").format(
            u(info.get("mapName") or ""), info.get("gridSize"), info.get("cellSize"), u(info.get("activeTool") or "")))

    for legacy in LEGACY_IDS:
        enabled, order = remove_plugin(plugins_dir, legacy, enabled, order)

    if "--undo" in sys.argv[1:]:
        enabled, order = remove_plugin(plugins_dir, PLUGIN_ID, enabled, order)
        save_state(state_path, enabled, order)
        out("Plugin \"Pink theme\" removed.")
        out("-> The editor is grey again (it reloads plugins by itself; otherwise Plugin Manager -> \"↻ Refresh\").")
        return 0

    manifest = {
        "format": 1,
        "id": PLUGIN_ID,
        "name": u("Pink theme"),
        "version": "1.1.0",
        "author": u("Test code (Python)"),
        "description": u("Pink editor colours instead of grey. Created by the test Python code from the 🌸 Pink test tab."),
        "theme": {"dark": DARK, "light": LIGHT},
    }
    if not os.path.isdir(folder):
        os.makedirs(folder)
    write_json(os.path.join(folder, "plugin.json"), manifest)

    if PLUGIN_ID not in enabled:
        enabled.append(PLUGIN_ID)
    order = [x for x in order if x != PLUGIN_ID] + [PLUGIN_ID]
    save_state(state_path, enabled, order)

    out("Plugin \"Pink theme\" installed and enabled.")
    out("-> The editor turns pink 🌸 (it reloads plugins by itself; otherwise Plugin Manager -> \"↻ Refresh\").")
    out("   (Back to grey: the \"↺ Back to grey\" button in the Pink test tab, or turn the plugin off in the Plugin Manager.)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
